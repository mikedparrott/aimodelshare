
# Currently package is limited to collaborative model building functions

# Function #1

def submit_model(model_filepath, model_eval_metrics, model, apiurl, username, password, aws_key, aws_password, region, trainingdata="default",preprocessor_filepath="default", preprocessor="default"):
        #add token creation code, dyndb update code, and s3update code
      import boto3
      import os

      # Dynamodb post to update version number and return bucket_name and unique_model_id data
      import boto3
      import botocore
      import os
      import requests
      import uuid 
      import json
      import math
      import time
      import datetime
      # Sign in functioning code chunk
      client_ci = boto3.client('cognito-idp', region_name="us-east-1")
      response=["0"]
      import tempfile
      tempdir = tempfile.TemporaryDirectory()
      model_eval_metrics['username'] = username
      model_eval_metrics_submissionid=str(uuid.uuid1().hex)
      model_eval_metrics_localfilename=tempdir.name+"/"+"model_eval_metrics_object"+"_"+model_eval_metrics_submissionid+".csv"
      try:
        import requests
        import botocore
        import boto3

        client_ci = boto3.client('cognito-idp', region_name="us-east-1")
        response=["0"]


        # User pool info
        cognitoregion="us-east-2"
        # User pool client id for app with Admin NO SRP Auth enabled
        config = botocore.config.Config(signature_version=botocore.UNSIGNED)

        # Get JWT token for the user
        provider_client=boto3.client('cognito-idp', region_name=cognitoregion, config=config)
        response = provider_client.initiate_auth(
        ClientId='57tnil9teheh8ic5ravno5c7ln',
        AuthFlow='USER_PASSWORD_AUTH',
        AuthParameters={
            'USERNAME': username,
            'PASSWORD': password
        })
        jwt_aws_token=response['AuthenticationResult']['IdToken']
        result={"username":username,"returned_jwt_token":jwt_aws_token}
        bodydata={"apideveloper":username,
                "apiurl":apiurl,
                "delete":"FALSE",
                "versionupdateget":"TRUE"
        }

        # Get the response
        headers_with_authentication= {'content-type': 'application/json', 'Authorization': jwt_aws_token}
        #modeltoapi lambda function invoked through below url to delete prediction api model details from aimodelshare website:

        r=requests.post("https://bbfgxopv21.execute-api.us-east-1.amazonaws.com/dev/todos", json=bodydata, headers=headers_with_authentication)                

        import json
        payload_updateget=json.loads(r.content.decode("utf-8"))
        assert r.status_code==200

      except AssertionError:  
        print("Your apiurl or sign-in credentials are incorrect.  Please change and resubmit.")

      try:  
          if all([os.environ.get("AWS_ACCESS_KEY_ID")!=None and os.environ.get("AWS_SECRET_ACCESS_KEY")!=None and os.environ.get("AWS_DEFAULT_REGION")!=None]):
              usersession = boto3.session.Session(aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'], aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'], region_name=os.environ['AWS_DEFAULT_REGION'])
              s3client = usersession.client('s3')
              s3resource = usersession.resource('s3')
              region=os.environ['AWS_DEFAULT_REGION']
          elif aws_key!=None:
              usersession = boto3.session.Session(aws_access_key_id=aws_key, aws_secret_access_key=aws_password, region_name=region)
              s3client = usersession.client('s3')
              s3resource = usersession.resource('s3')
      except:
          print("Please set your aws credentials before creating your prediction API.")

      try:

              bucket_name=payload_updateget[1]
              unique_model_id=payload_updateget[2]
              # List files

              objectsinbucket=s3client.list_objects(Bucket=bucket_name, Prefix=unique_model_id+'/predictionmodel')

              file_list = []
              for key in objectsinbucket['Contents']:
                  file_list.append(key['Key'].split("/")[1])

              # Extract current and new version of model

              fileversionlist = [str(sub).replace(".","_").split('_')[2] for sub in file_list] 
              mostrecent_modelname = [i for i in file_list if "mostrecent" in i] 
              
              deletionobject = s3resource.Object(bucket_name,str(unique_model_id)+"/"+str(mostrecent_modelname[0]))
              deletionobject.delete()   
      except:
        pass  

      try:

              bucket_name=payload_updateget[1]
              unique_model_id=payload_updateget[2]
              # List files

              objectsinbucket=s3client.list_objects(Bucket=bucket_name, Prefix=unique_model_id+'/predictionmodel')

              file_list = []
              for key in objectsinbucket['Contents']:
                  file_list.append(key['Key'].split("/")[1])

              # Extract current and new version of model

              fileversionlist = [str(sub).replace(".","_").split('_')[2] for sub in file_list] 
              mostrecent_modelname = [i for i in file_list if "mostrecent" in i] 
              
              deletionobject = s3resource.Object(bucket_name,str(unique_model_id)+"/"+str(mostrecent_modelname[0]))
              deletionobject.delete()   
      except:
        pass  

      #Pandas training data pointer (currently for data updates only)
      import pandas as pd
      import numpy as np

      if isinstance(trainingdata, pd.DataFrame):
            variabletypes=list(trainingdata.dtypes.values.astype(str)) # always use pandas dtypes
            variablecolumns=list(trainingdata.columns)
      else: 
            variabletypes=None
            variablecolumns=None
      
      
      variablename_and_type_data=variabletypes, variablecolumns


      if any([str(type(model)).find("keras")>-1 ]):
            import tensorflow.keras.backend as K
            from tensorflow.keras.models import model_from_yaml
            model_config=model.to_yaml()
            model_optim_config=str(K.eval(model.optimizer.get_config())) # Optimizer configuration
            training_epochs=len(model.history.epoch) # Number of epochs
      else: 
            model_config="no config data" # Full configuration to fit keras model
            model_optim_config="no optimization data"  # Optimizer configuration
            training_epochs="no epoch data" # Number of epochs            

      if any([str(type(model)).find("sklearn")>-1 ]):
            model_config=str(model) # Full configuration to fit keras model
            model_optim_config="no optimization data"  # Optimizer configuration
            training_epochs="no epoch data" # Number of epochs    
      else: 
            model_config=model_config # Full configuration to fit keras model
            model_optim_config=model_optim_config  # Optimizer configuration
            training_epochs=training_epochs # Number of epochs       
      
 

      try:
              bucket_name=payload_updateget[1]
              unique_model_id=payload_updateget[2]
              # List files

              objectsinbucket=s3client.list_objects(Bucket=bucket_name, Prefix=unique_model_id+'/predictionmodel')

              file_list = []
              for key in objectsinbucket['Contents']:
                  file_list.append(key['Key'].split("/")[1])

              # Extract current and new version of model

              fileversionlist = [str(sub).replace(".","_").split('_')[2] for sub in file_list] 
              mostrecent_modelname = [i for i in file_list if "mostrecent" in i] 
              
              subset = list(map(lambda x: x.isnumeric(), fileversionlist))

              from itertools import compress
              fileversionlist_numbersonly=list(compress(fileversionlist, subset))
              subsettointeger = list(map(lambda x: int(x), fileversionlist_numbersonly))
              previousversion=max(subsettointeger)
              versiontoupdate=previousversion+1
              versiontoupdate #use me in newest model filename.  earlier in function you will need to take previous version from dyndb and sent through update post to change in dyndb

              # Load model to user bucket

              Filepath=model_filepath # needs to use double backslashes and have full filepath
              Filename=os.path.basename(Filepath)
              filename, file_extension = os.path.splitext(Filename)

              filenameoriginalmodel, file_extensionoriginalmodel = os.path.splitext(file_list[0])

              # Check for preprocessor file
              if preprocessor!="TRUE":
                preprocessor=preprocessor
                preprocessorFilepath=preprocessor
                preprocessorfile_extension=preprocessor

              else:
                  preprocessor=preprocessor 
                  preprocessorFilepath=preprocessor_filepath # needs to use double backslashes and have full filepath
                  preprocessorFilename=os.path.basename(preprocessorFilepath)
                  preprocessorfilename, preprocessorfile_extension = os.path.splitext(preprocessorFilename)
                  userKEY=bucket_name+"/"+unique_model_id+"/"
                  preprocessorfileKEY=unique_model_id+"/preprocessor_mostrecent"+preprocessorfile_extension
                  preprocessorversionfileKEY=unique_model_id+"/preprocessor_"+str(versiontoupdate)+preprocessorfile_extension
                  response2=s3client.upload_file(preprocessorFilepath, bucket_name,  preprocessorfileKEY) 
                  response2_5=s3client.upload_file(preprocessorFilepath, bucket_name,  preprocessorversionfileKEY) 
      except:  
            print("Please review model details and then resubmit to update this model.")

      else:
                  userKEY=bucket_name+"/"+unique_model_id+"/"
                  if file_extension==".pkl":
                      fileKEY=unique_model_id+"/predictionmodel_sklearn_mostrecent"+file_extension
                      fileKEYnewversion=unique_model_id+"/predictionmodel_sklearn_"+str(versiontoupdate)+file_extension
                  else:
                      fileKEY=unique_model_id+"/predictionmodel_kerasonnx_mostrecent"+file_extension
                      fileKEYnewversion=unique_model_id+"/predictionmodel_kerasonnx_"+str(versiontoupdate)+file_extension                 
                  
                  response2=s3client.upload_file(Filepath, bucket_name,  fileKEY) 
                  response2_5=s3client.upload_file(Filepath, bucket_name,  fileKEYnewversion) 
                  try:
                        obj = s3client.get_object(Bucket=bucket_name, Key=unique_model_id+"/model_eval_data_mastertable.csv")
                  except:
                      var_exists = False
                  else:
                      var_exists = True

                  if var_exists == True:
                      df = pd.read_csv(obj['Body'])
                      if str(df.columns).find('model_config')==-1:
                        df['model_config']="no config data"
                        df['model_optim_config']="no config data"
                        df['model_epochs']="no config data"
                      else:
                        print("")
                      model_eval_metrics['username']=username
                      model_eval_metrics["model_version"]= str(versiontoupdate)
                      model_eval_metrics["model_config"]= model_config
                      model_eval_metrics["model_optim_config"]= model_optim_config
                      model_eval_metrics["model_epochs"]= training_epochs
          
                      df_updated=df.append(model_eval_metrics, ignore_index=True,sort=False)

                      model_eval_metrics_localfilename=tempdir.name+"/"+"model_eval_metrics_object"+"_"+model_eval_metrics_submissionid+".csv"
                      df_updated.to_csv(model_eval_metrics_localfilename,index=False)
                      model_eval_metrics_unique_filekey=unique_model_id+"/model_eval_data_mastertable.csv"
                      response_modeleval=s3client.upload_file(model_eval_metrics_localfilename, bucket_name,  model_eval_metrics_unique_filekey) 
                  else:  
                      model_eval_metrics['username']=username
                      model_eval_metrics["model_version"]= str(versiontoupdate)
                      model_eval_metrics["model_config"]= model_config
                      model_eval_metrics["model_optim_config"]= model_optim_config
                      model_eval_metrics["model_epochs"]= training_epochs
                      model_eval_metrics_localfilename=tempdir.name+"/"+"model_eval_metrics_object"+"_"+model_eval_metrics_submissionid+".csv"
                      model_eval_metrics.to_csv(model_eval_metrics_localfilename,index=False)
                      model_eval_metrics_unique_filekey=unique_model_id+"/model_eval_data_mastertable.csv"
                      response_modeleval=s3client.upload_file(model_eval_metrics_localfilename, bucket_name,  model_eval_metrics_unique_filekey) 

                  bodydata={"apideveloper":username,
                            "apiurl":apiurl,
                            "delete":"FALSE",
                            "versionupdateget":"FALSE",
                            "versionupdateput":"TRUE",
                            "version":versiontoupdate,
                            "input_feature_dtypes":variablename_and_type_data[0],
                            "input_feature_names":variablename_and_type_data[1]
                    }
                                      # Get the response
                  headers_with_authentication= {'content-type': 'application/json', 'Authorization': jwt_aws_token}


                  #post lambda function invoked through below url to update prediction api model details listed on aimodelshare website:

                  r2=requests.post("https://bbfgxopv21.execute-api.us-east-1.amazonaws.com/dev/todos", json=bodydata, headers=headers_with_authentication)  
                  print('"'+model_filepath+'" '+'has been loaded to version '+str(versiontoupdate)+' of your prediction API.\nThis version of the model will be used by your prediction api for all future predictions automatically.\nIf you wish to use an older version of the model, please reference the getting started guide at aimodelshare.com.')
      return 
  


# Function #2

def get_leaderboard(apiurl, username, password, aws_key, aws_password, region):
        #add token creation code, dyndb update code, and s3update code

      # Dynamodb post to update version number and return bucket_name and unique_model_id data
      import boto3
      import botocore
      import os
      import requests
      import uuid 
      import json
      import math
      import time
      import datetime
      import pandas as pd
      # Sign in functioning code chunk
      client_ci = boto3.client('cognito-idp', region_name="us-east-1")
      response=["0"]
      import tempfile

      try:
        import requests
        import botocore
        import boto3

        client_ci = boto3.client('cognito-idp', region_name="us-east-1")
        response=["0"]


        # User pool info
        cognitoregion="us-east-2"
        # User pool client id for app with Admin NO SRP Auth enabled
        config = botocore.config.Config(signature_version=botocore.UNSIGNED)

        # Get JWT token for the user
        provider_client=boto3.client('cognito-idp', region_name=cognitoregion, config=config)
        response = provider_client.initiate_auth(
        ClientId='57tnil9teheh8ic5ravno5c7ln',
        AuthFlow='USER_PASSWORD_AUTH',
        AuthParameters={
            'USERNAME': username,
            'PASSWORD': password
        })
        jwt_aws_token=response['AuthenticationResult']['IdToken']
        result={"username":username,"returned_jwt_token":jwt_aws_token}
        bodydata={"apideveloper":username,
                "apiurl":apiurl,
                "delete":"FALSE",
                "versionupdateget":"TRUE"
        }

        # Get the response
        headers_with_authentication= {'content-type': 'application/json', 'Authorization': jwt_aws_token}
        #modeltoapi lambda function invoked through below url to delete prediction api model details from aimodelshare website:

        r=requests.post("https://bbfgxopv21.execute-api.us-east-1.amazonaws.com/dev/todos", json=bodydata, headers=headers_with_authentication)                

        import json
        payload_updateget=json.loads(r.content.decode("utf-8"))
        assert r.status_code==200

      except AssertionError:  
        print("Your apiurl or sign-in credentials are incorrect.  Please change and resubmit.")

      try:  
          if all([os.environ.get("AWS_ACCESS_KEY_ID")!=None and os.environ.get("AWS_SECRET_ACCESS_KEY")!=None and os.environ.get("AWS_DEFAULT_REGION")!=None]):
              usersession = boto3.session.Session(aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'], aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'], region_name=os.environ['AWS_DEFAULT_REGION'])
              s3client = usersession.client('s3')
              s3resource = usersession.resource('s3')
              region=os.environ['AWS_DEFAULT_REGION']
          elif aws_key!=None:
              usersession = boto3.session.Session(aws_access_key_id=aws_key, aws_secret_access_key=aws_password, region_name=region)
              s3client = usersession.client('s3')
              s3resource = usersession.resource('s3')
      except:
          print("Please set your aws credentials before creating your prediction API.")

      try:

              bucket_name=payload_updateget[1]
              unique_model_id=payload_updateget[2]
              # List files

              obj = s3client.get_object(Bucket=bucket_name, Key=unique_model_id+"/model_eval_data_mastertable.csv")
              leaderboard = pd.read_csv(obj['Body'])
              # is this ranking larger values as better or smaller?  Careful!
              model_config=leaderboard['model_config']
              model_optim_config=leaderboard['model_optim_config']
              model_epochs=leaderboard['model_epochs']

              leaderboard.drop(leaderboard.loc[:, 'model_config':'model_epochs'].columns, axis = 1, inplace=True) 


              leaderboard['mse']=leaderboard['mse']*-1
              leaderboard['rmse']=leaderboard['rmse']*-1
              leaderboard['mae']=leaderboard['mae']*-1

              leaderboard['ranking_accuracy']= leaderboard['accuracy'].rank(method='dense', ascending=False)
              leaderboard['ranking_f1_score']= leaderboard['f1_score'].rank(method='dense', ascending=False)
              leaderboard['ranking_precision']= leaderboard['precision'].rank(method='dense', ascending=False)
              leaderboard['ranking_recall']= leaderboard['recall'].rank(method='dense', ascending=False)
              leaderboard['ranking_mse']= leaderboard['mse'].rank(method='dense', ascending=False)
              leaderboard['ranking_mae']= leaderboard['mae'].rank(method='dense', ascending=False)
              leaderboard['ranking_rmse']= leaderboard['rmse'].rank(method='dense', ascending=False)
              leaderboard['ranking_r2']= leaderboard['r2'].rank(method='dense', ascending=False)
              leaderboard['avg_ranking_allmetrics']= leaderboard.iloc[:,10:16].mean(axis=1)
              leaderboard['avg_ranking_classification']= leaderboard.iloc[:,10:13].mean(axis=1)
              leaderboard['avg_ranking_regression']= leaderboard.iloc[:,14:16].mean(axis=1)
              leaderboard.sort_values(by=['avg_ranking_allmetrics'],inplace=True)
              leaderboard.drop(leaderboard.loc[:, 'ranking_accuracy':'avg_ranking_allmetrics'].columns, axis = 1, inplace=True) 
              leaderboard['model_config']=model_config
              leaderboard['model_optim_config']=model_optim_config
              leaderboard['model_epochs']=model_epochs
              display(leaderboard)

      except:  
            print("Please review function args and then resubmit to generate a leaderboard.")
      return leaderboard